def GetImages(artist):
    return []
