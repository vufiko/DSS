def GetImages(artist):
    return []