import xbmcgui

	
	
xbmcgui.Dialog().ok("Dutch Sport Streams", "Dutch Sport Streams Is verhuist naar Dutch Cloud TV! ", "Met vriendelijke groet Dutch Sport Streams", "HTTP://WWW.DUTCHSPORTSTREAMS.COM")
